#include <iostream>
#include <stdexcept>
#include <iomanip>
#include <string>
#include "Term.cpp"

using namespace std;

int main(){
    Term k(2,3); 
    Term r;

    cin >> r;
    cout << endl << " Adding " << r  << " + " << k + r  <<endl;
    cout << endl << " Subtracting "<< r << " - " << k - r << endl; 
    cout << endl << " Multiplying " << r << " * " << k * r <<endl;
    cout << endl << " Divisioning " << r << " / " << k / r << endl;
    cout << endl << " Ostreaming " << r << " << " << k + r << endl;
    cout << endl << " istreaming " << r << " >> "<< k + r  <<endl;
}