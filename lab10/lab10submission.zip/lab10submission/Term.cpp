#include "Term.h"
#include <iostream>
#include <stdexcept>
#include <iomanip>
#include <string>

using namespace std;

    Term::Term ( int coef, int exp ){
        this -> coefficient = coef;
        this -> exponent = exp;
    }
    Term& Term::setCoefficient ( int coef){
        coefficient = coef;
    }
    Term& Term::setExponent ( int exp){
        exponent = exp;
    }
    int Term::getCoefficient ( ) const{
        return coefficient;
    }
    int Term::getExponent( ) const{
        return exponent;
    }
    Term Term::operator+ (const Term & T)const{
        Term answer = *this;
        if(exponent != T.getExponent()){
            throw invalid_argument("Cant add those!");
        }else{
            answer.setCoefficient( T.getCoefficient() + answer.getCoefficient() );
        }
        return answer;
    }
    Term Term::operator- (const Term & T)const{
        Term answer = *this;
        if(exponent != T.getExponent()){
            throw invalid_argument("Cant add those!");
        }else{
            answer.setCoefficient( T.getCoefficient() - answer.getCoefficient()  );
        }
        return answer;
    }
    Term Term::operator* (const Term & T)const{
        Term answer;
            answer.setCoefficient( answer.getCoefficient() * T.getCoefficient() );
            answer.setExponent( answer.getExponent() + answer.getExponent() );
            return answer;
    }
    Term Term::operator/ (const Term & T)const{
        Term answer;
            answer.setCoefficient( answer.coefficient / T.coefficient );
            answer.setExponent( answer.exponent - answer.coefficient );
            return answer;

    }
    ostream& operator<<(ostream & out, const Term& t){
        out << t.coefficient << "x^" << t.exponent << endl;
        return out;
    }
    inline istream& operator>>(istream & in, Term& t){
        in >> t.coefficient; 
        in.ignore(2); 
        in >> t.exponent;
        return in;
    }
